print(f1, 'RDM', '-depsc');
saveas(f1, 'RDM', 'fig');
print(f2, 'MDS', '-depsc');
saveas(f2, 'MDS', 'fig');
print(f3, 'Dendro', '-depsc');
saveas(f3, 'Dendro', 'fig');
print(f4, 'MST', '-depsc');
saveas(f4, 'MST', 'fig');
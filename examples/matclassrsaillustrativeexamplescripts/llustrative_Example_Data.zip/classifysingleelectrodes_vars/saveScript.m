saveas(gcf, 'Egi', 'eps');
saveas(gcf, 'Egi', 'fig');
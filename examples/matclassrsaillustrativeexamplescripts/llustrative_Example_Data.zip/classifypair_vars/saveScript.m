saveas(f1, 'RDM', 'eps');
saveas(f1, 'RDM', 'fig');
saveas(f2, 'MDS', 'eps');
saveas(f2, 'MDS', 'fig');
saveas(f3, 'Dendro', 'eps');
saveas(f3, 'Dendro', 'fig');
saveas(f4, 'MST', 'eps');
saveas(f4, 'MST', 'fig');